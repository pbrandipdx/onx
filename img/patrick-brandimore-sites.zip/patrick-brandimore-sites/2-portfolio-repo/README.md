# Patrick Brandimore — patrickbrandimore.github.io

The general-purpose site. One file, `index.html`. No build step, no dependencies, no framework, no trackers. Open it in a browser to preview.

An interactive career timeline: eight capability filters mark matching work across every role with a highlighter sweep and fade the rest back. Roles expand and collapse. It prints cleanly, so Cmd/Ctrl+P doubles as a PDF resume.

## Publish on GitHub Pages

1. Create a **public** repo named `patrickbrandimore.github.io` — that puts the site at `https://patrickbrandimore.github.io`. (Any other name works too; it just lands at `username.github.io/repo-name`.)
2. Upload `index.html` to the repo root. **Add file → Upload files** and drag it in.
3. **Settings → Pages**.
4. Source: **Deploy from a branch**. Branch `main`, folder `/ (root)`. Save.
5. Wait a minute, reload, and your URL appears at the top.

From the command line instead:

```bash
git init
git add index.html README.md
git commit -m "Add site"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/patrickbrandimore.github.io.git
git push -u origin main
```

## Custom domain

In **Settings → Pages → Custom domain**, enter your domain. At your registrar add four `A` records for the apex pointing to `185.199.108.153`, `185.199.109.153`, `185.199.110.153`, `185.199.111.153`, and a `CNAME` for `www` pointing to `YOUR-USERNAME.github.io`. Tick **Enforce HTTPS** once the certificate provisions.

## Editing

Everything lives in two arrays in the `<script>` block near the bottom.

`TAGS` defines the filter chips:

```js
{id:"ai", label:"Agentic AI"}
```

`ROLES` defines the timeline:

```js
{
  title:"Lead Product Manager, Nike Digital",
  org:"Nike", place:"Beaverton, OR",
  from:"Mar 2025", to:"Jul 2026", open:true,
  points:[
    {t:"What you did.", tags:["ai","commerce"]}
  ]
}
```

- `open: true` starts the role expanded; `false` collapsed.
- `current: true` fills the timeline dot in blue.
- `tags` must match ids from `TAGS`. Add a new tag there and its chip appears automatically.

Colors are the CSS variables in `:root` at the top of the `<style>` block.

## Note

Your phone number is deliberately not on the page — public pages get scraped. Add it to `.masthead-meta` if you want it.
