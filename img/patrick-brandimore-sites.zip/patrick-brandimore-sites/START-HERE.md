# Patrick Brandimore — sites bundle

Four folders. Two go to GitHub, two do not.

---

## 1-onx-repo → upload to a repo named `onx`

Written for **Senior Product Manager, Content (Offroad)** at onX.

| File | What it is |
|---|---|
| `index.html` | The case. Six duties mapped, six jobs told as stories, plus your offroad photos. |
| `landscape.html` | Your content-and-data-strategy analysis. |
| `img/` | 13 WebP images. **Must be uploaded** or every photo breaks. |

Result: `https://pbrandipdx.github.io/onx`

## 2-portfolio-repo → upload to a repo named `pbrandipdx.github.io`

The general-purpose site. Nike design language, 36 projects, two case studies. One file, no images.

Result: `https://pbrandipdx.github.io`

---

## previews-do-not-upload

Same pages with images baked in as base64 so they render when opened directly from your machine. **Do not put these in a repo** — they're 12× larger and reintroduce the loading problem you hit earlier.

Use them to check your work locally, then upload the real versions.

## private-notes

`onx-interview-prep.md` — process map, gap analysis, STAR stories, values prep, questions, and the resume/LinkedIn conflicts. **Keep this off GitHub.**

---

## Publishing, either repo

1. github.com → **New repository** → public → name it as above → Create
2. **Add file → Upload files** → drag in everything from that folder, `img/` included
3. Commit
4. **Settings → Pages** → Source: *Deploy from a branch* → `main` → `/ (root)` → Save
5. Wait a minute, reload the Pages screen, and the URL appears at the top

Command line instead:

```bash
cd 1-onx-repo
git init && git add . && git commit -m "Add site"
git branch -M main
git remote add origin https://github.com/pbrandipdx/onx.git
git push -u origin main
```

---

## Still open

- **No contact details on the onX page.** You removed the footer with your email and LinkedIn and nothing replaced it. On a page you're sending a recruiter, that's a gap.
- **Job 01 dates the PLM work to 2026.** Your resume says that work started May 2025 under a differently-named role. Check before publishing.
- **Read the offroad captions.** I wrote them from the photos alone. They avoid naming places, but a couple make claims about what you've done — fix anything that isn't true.
- **Your resume disagrees with LinkedIn** on five points. Both sites use the LinkedIn timeline, so the PDF is the odd one out. Details in `private-notes`.
