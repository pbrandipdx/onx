# Patrick Brandimore — for onX

Two pages, one visual system. Written for **Senior Product Manager, Content (Offroad)**.

| File | What it is |
|---|---|
| `index.html` | **The case.** Nine duties from the posting mapped green / amber / grey, then the seven jobs told as stories — the situation, the hard part, and why it carries over to a trail record. |
| `landscape.html` | **The homework.** Your content-and-data-strategy analysis, unchanged except for the brandbar and a link back to `index.html`. |

Both are self-contained. Same stylesheet, same tokens, same components — `index.html` was built from `landscape.html`'s CSS, so they read as one document in two parts.

## What was reused, not reinvented

`index.html` uses your existing component vocabulary rather than new classes:

- `.rmap` / `.rrow` / `.rst` — your duty-to-evidence rows with the green / amber / grey status pills. This component already existed and was exactly right for the nine-duty summary.
- `.stage` / `.obs` — your pipeline stages carry the seven job stories, with `.obs` doing triple duty as Signal, Where and Transfer labels.
- `.lq` — the blue-bordered learning cards hold the two gaps.
- `.spine`, `.asks`, `.pull`, `.part-i`, `.snum`, `.jump` — all yours.

The only additions are `.jump a` (your pill styling applied to links rather than buttons) and `.todo`, a red dashed box using `--stale`.

## Before you publish

1. **Write the offroad section** in `index.html` (`id="offroad"`). It's a red dashed box addressed to you and it renders live exactly as written.
2. **Decide which page is the landing page.** As shipped, `index.html` is the case and `landscape.html` is the evidence. A recruiter needs to know who you are before they'll read a data-model teardown. If you'd rather lead with the analysis, swap the filenames.
3. `landscape.html` is `noindex, nofollow`. `index.html` matches. Remove those tags if you want either indexed.

## Publish

Upload both files to the repo root, then **Settings → Pages → Deploy from a branch**, `main`, `/ (root)`. Put the resulting URL in the Website field on the Greenhouse application.

## Images

The five screenshots in `landscape.html` were embedded as base64 JPEGs, which put 462KB inside the HTML itself. Nothing on the page could render until all of it downloaded — that's the timeout.

They now live in `img/` as WebP and load lazily:

| | Before | After |
|---|---|---|
| Images | 462 KB | 209 KB |
| `landscape.html` | 721 KB | 104 KB |
| Bytes before first paint | 721 KB | 104 KB |

Two changes did it. Resizing 620px wide to 512px — they display at roughly 256px in the 5-column grid, so 512 covers retina with nothing wasted. And WebP instead of JPEG, which is about 40% smaller on map screenshots at the same quality.

Each `<img>` now carries `loading="lazy"` (they sit far down the page, so they don't load until scrolled near), `decoding="async"`, and explicit `width`/`height` so the layout doesn't jump as they arrive.

**Upload the `img/` folder along with the HTML files.** Relative paths break if it's missing.

### Adding more images

```
img/your-image.webp
<img src="img/your-image.webp" width="512" height="1112" loading="lazy" decoding="async" alt="...">
```

Resize to roughly twice display width and save as WebP at quality 72. Keep anything above the fold off `loading="lazy"` — it delays images the visitor can already see. And never paste base64 into the HTML again; it defeats browser caching, so every visit re-downloads the images.
