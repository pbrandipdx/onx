# onX — Senior Product Manager, Content (Offroad)

Prep notes. Not for the website — this is yours.

**Role:** Senior PM, Content (Offroad) · Reports to Head of Product, Offroad · Portland Basecamp · $143–179K + 10% bonus + options

---

## ⚠ Fix this first: your resume and LinkedIn don't match

Recruiters cross-check these. onX's process opens with a recruiter screen, and mismatched dates are the single most common thing that stalls a candidate before the hiring manager ever sees them. Every one of these is visible to anyone with both documents open.

| | Resume says | LinkedIn says |
|---|---|---|
| Current role title | AI Lead – Consumer Product & Innovation | Technical AI Product Manager – Consumer, Product & Innovation |
| Current role start | May 2025 | Apr 2026 |
| Commerce role title | Product Lead – Buy & Post-Purchase | Lead Product Manager – Nike Digital |
| Commerce role dates | Jan 2025 – Present | Mar 2025 – **Jul 2026 (ended)** |
| Connected Sport end | Jan 2025 | Mar 2025 |
| Global Brand DM start | Oct 2013 | Oct 2012 |
| Career length | "20+ years" | Jan 2010 start = **16 yrs 8 mos** |

**The three that matter:**

1. **Your resume shows two concurrent "Present" roles. LinkedIn shows them sequential, with Nike Digital ending in July.** A recruiter reading both can't tell what you do today. Pick one story and make both documents tell it. If you genuinely held both during the Apr–Jul 2026 overlap, say so explicitly on the resume — "transitioned from X to Y over Q2 2026" — rather than leaving two open end dates.

2. **"20+ years" doesn't survive arithmetic.** Your earliest listed job is January 2010. That's 16 years and 8 months. If you have pre-2010 experience, get it onto LinkedIn. If you don't, change the resume to "15+ years" — which still clears their 8-year bar twice over, so you lose nothing and remove a reason to doubt you. I've set both web pages to sixteen years, fourteen at Nike.

3. **A one-year gap in your current-role start date.** May 2025 versus April 2026 is the kind of discrepancy that reads as either carelessness or padding. Neither is what you want.

**Things LinkedIn has that your resume dropped — put them back:**

- **Nike.com.** It appears under two of your roles on LinkedIn and nowhere on your resume. Owning cart and checkout for Nike.com is a bigger credential than "Buy & Post-Purchase" conveys.
- **COROS and Apple Watch.** Your resume lists three integration partners; LinkedIn shows five. For a job about evaluating and reconciling third-party data sources, five sources feeding one activity record is a materially stronger claim than three. I've updated both pages.
- **"Nike Adapt Platform"** rather than "HyperAdapt 1.0 app." A platform that later products were built on beats a one-off app.
- **Connected Sport was 4 years 10 months**, not the ~4.5 the resume implies. Round up honestly.

I've rebuilt both web pages on the LinkedIn timeline, since that's the version a recruiter can verify. **Your resume is now the document that's out of step — update it before you apply.**

---

## The process, and what each stage is actually testing

From their FAQ, the shape is: recruiter phone screen → hiring manager video → team panel → possible take-home. Two to three weeks. All virtual, camera on, Google Meet. Response within 5–7 business days.

| Stage | What they're really checking |
|---|---|
| Recruiter phone screen | Have you used the product. Do you have offroad ties. Are you in a hire-able state. Comp alignment. |
| Hiring manager (Head of Product, Offroad) | Can you own a content and data strategy, not just execute a roadmap. Do you have a point of view. |
| Team panel | Can you move between a schema conversation and a partner conversation in the same day — they say this explicitly. Values fit. |
| Take-home, if it comes | Almost certainly a content/data strategy exercise for Offroad. See below. |

**Do this before the phone screen:** download onX Offroad, take the 7-day trial, and actually drive something. The FAQ says they love hearing how candidates have experienced the products, which means the recruiter is going to ask and will hear the difference between "I explored the app" and "I ran the Tillamook State Forest with it and here's what I noticed."

---

## Their values, and your story for each

onX's four values: **Solve What Matters · Expedition Together · Discover New Paths · Get After It**

Solve What Matters expands to: fixing meaningful problems, know your customer, tackle the root cause, own your impact. Expedition Together: working as a team with purpose, humility, and support.

Note "tackle the root cause" — that's not generic. They're telling you they value fixing the upstream thing rather than patching symptoms.

- **Solve What Matters** → Zero Undeliverables. Failed deliveries looked like a logistics problem. You went upstream to address data quality at entry. $48M/yr projected, 50–75x ROI on Japan. This is literally "tackle the root cause" and "own your impact" in one story. **Lead with this one.**
- **Expedition Together** → The PM AI Toolkit spreading to two organizations by adoption rather than mandate. The humility angle: you built it for your own team and other people asked for it. Have a version of this that credits specific colleagues.
- **Discover New Paths** → Connected Jersey or HyperAdapt. A product category that didn't exist. Or the Google UCP integration — first agentic commerce experience at Nike, no playbook.
- **Get After It** → Pick the one with the tightest deadline. 2014 World Cup activation, or shipping UCP in time for Google I/O.

---

## Requirement-by-requirement: where you stand

**Strong, no work needed**
- 8+ years leading software products (you have 20), 4+ in PM
- Consumer technology at scale
- Translating customer needs into data-model requirements with product/design/eng — the PLM platform is a near-exact match
- Curiosity for AI — you're not just qualified here, you're overqualified, and the JD explicitly asks for AI as a repeatable co-pilot
- Measurement and ROI ownership
- Portland is a listed Basecamp
- Comfort moving between technical and relationship conversations

**Adjacent — needs a bridge you say out loud**
- **Third-party data partnerships.** You have Google, Garmin, Strava. They want land agencies and geospatial licensors. Bridge: "I've negotiated data contracts where the hard part was deciding who owns the record when systems disagree."
- **People leadership.** The role has a direct report (Trail Guide Program Owner). Your resume shows influence without authority, not line management. If you have managed people directly, get it onto the resume — it's a listed requirement and its absence is conspicuous.
- **Program management, 3 years.** There's a screening question on this in the application. Zero Undeliverables across three regions is program management; frame it that way, don't call it product management.

**Real gaps**
- **Geospatial/GIS.** No evidence. Don't pretend. Say the concepts port and the vocabulary doesn't yet.
- **Land management agencies (BLM, USFS).** None.
- **Contributor/community program scaling.** None visible. If you've run anything ambassador-like, surface it.
- **Offroad/overlanding/powersports ties.** This is a stated requirement and I have no information about you here. See below.

---

## The offroad question — deal with this first

They wrote "genuine, credible ties to the off-road, overlanding, or powersports community" into the requirements. onX is a company of people who do the thing. The recruiter will ask on the first call.

Three honest scenarios:

1. **You're in it.** Then lead with it in the first thirty seconds of the phone screen, with specifics — rig, trails, the group you go with. This flips your whole application.
2. **You're outdoors-adjacent but not offroad.** Say exactly that, then bridge to what you do have. Trail running, hiking, skiing, hunting — any of it means you've used maps where being wrong matters. Then be specific about what's pulling you toward offroad.
3. **No real connection.** This is your biggest risk. You can't manufacture it in two weeks, but you can start: take the Offroad trial, drive real trails in the Coast Range or Mount Hood National Forest, and come to the call with observations rather than claims. "I've been running it for three weeks and here's where the trail data let me down" is a credible answer. Pretending is not, and they'll catch it.

**Tell me which of these is true and I'll rewrite that section of the onX page properly.**

---

## Stories, in STAR shape

Have these tight enough to tell in two minutes.

**1. Zero Undeliverables — root cause, measured impact**
S: Failed deliveries across Japan, Korea, EMEA, treated as a fulfillment cost.
T: You believed it was a data problem at entry.
A: Built the case, drove global address validation across three regions.
R: $48M+ projected annual savings, 50–75x ROI on Japan.
*Use for:* Solve What Matters, measurement/ROI, global scale, influence without authority.

**2. PLM platform — owning a data model**
S: Merch planning, design, and development each had their own tools and their own version of the truth.
T: One connected source of truth for how physical product gets made.
A: Defined the entities, relationships, and ownership; got three functions to build against one model.
R: Product Brief tooling replaced static Keynote decks with live-linked data streaming downstream.
*Use for:* the core requirement of this job. This is your single most relevant story. Rehearse it most.

**3. PM AI Toolkit — AI as real working leverage**
S: PMs losing days to PRD writing and Jira transcription.
T: Make AI useful in the actual workflow, not a demo.
A: Ten agents, MCP-connected to Jira, Confluence, Figma, Adobe Analytics, Databricks, Qualtrics.
R: Adopted across two organizations voluntarily.
*Use for:* the AI requirement, Expedition Together, and their "experimentation mindset" language.

**4. Google UCP — external data partnership under deadline**
S: No agentic commerce capability at Nike.
T: Ship one with Google, in time for I/O.
A: Led the integration end to end — order-lifecycle event pipeline, Google Pay checkout, and the data contract with an external partner.
R: Nike's first agentic commerce experience, debuted at Google I/O.
*Use for:* partnerships, Discover New Paths, Get After It.

**5. NRC/NTC — content as the product**
S: Fitness apps live or die on whether the content means something next week.
T: Lift retention and engagement globally.
A: Research-to-roadmap loop, plus Garmin/Strava/Wear OS integrations into one coherent activity record.
R: Measured retention lift; a richer data ecosystem.
*Use for:* customer JTBD, third-party data evaluation, "thinking beyond the data model."

**6. Something that failed.** You need one. Pick a real prototype or partnership that didn't work, and be specific about what you'd do differently. A 20-year career with no failure story reads as evasive.

---

## The application's written question

> *"Please briefly describe your experience in content strategy, data management, and/or program management, including the type of work you owned and your level of responsibility."*

Draft answer, tighten to your own voice:

> At Nike I own the content and data model behind our next-generation product line management platform — the connected source of truth that merch planning, design, and development work from when physical product is made. I define what the entities are, how they relate, what inherits from what, and who owns each field, then partner with design and engineering to build against it. That includes the Product Brief system, which replaced static decks with a live-linked brief that streams updates downstream as source data changes.
>
> On the data management side, I led Zero Undeliverables across Japan, Korea, and EMEA — a global address-validation program projected to save over $48M annually with 50–75x return on the initial Japan deployment. That was program management as much as product: three regions, multiple engineering teams, no direct authority.
>
> I've also owned third-party data relationships end to end — five wearable and platform integrations for Nike's fitness apps (Garmin, COROS, Strava, Apple Watch, Wear OS), reconciled into a single activity record — plus the data contract behind our Universal Commerce Protocol integration with Google. Before that I led cart and checkout for Nike.com and the Nike App.

---

## If there's a take-home

Likely prompt: something like *"How would you approach Offroad's content and data strategy over the next year?"*

What would make yours stand out:
- **Start from a customer moment, not a schema.** "It's 4pm, you're 30 miles in, and you need to know if the road ahead is seasonally closed." Then work backward to what data that requires.
- **Separate coverage, freshness, and accuracy.** They're three different problems with three different solutions (licensing, community, validation). Most candidates blur them.
- **Say what you won't do.** A strategy without a stated non-goal isn't a strategy. This also hits "priorities matter" from their culture copy.
- **Include one measurement proposal.** They explicitly want content ROI owned. Propose how you'd instrument it.
- **Use AI visibly but with judgment.** They want to see thoughtful use. Show where you'd apply it and where you wouldn't trust it — content that affects whether someone is legally on public land is a place for human validation.

---

## Questions to ask

**Recruiter:** Where is Offroad in maturity relative to Hunt? What does the team look like today? Timeline and next steps?

**Hiring manager:** Where does Offroad's content lose customer trust today — coverage, freshness, or accuracy? How much of the roadmap is gated on licensing versus building? What would make you say this hire went well twelve months in?

**Team:** What breaks most often in the current data pipeline? What does the Trail Guide program owner need that they aren't getting? Where does the content model fight you?

**Anyone:** They say "ambiguity is part of the job" and also "we're not a scrappy start-up." Ask how those two coexist in practice — it's a genuinely interesting tension and asking about it shows you read carefully.

---

## Housekeeping

- Camera-ready. Google Meet. All virtual.
- Recruiter is your single point of contact; `recruitment@onXmaps.com` as backup.
- They may record interviews — you can opt out.
- Comp band is $143–179K. Know your number before the recruiter call, because it usually comes up there.
- Screening questions confirm 4+ years PM and 3+ years content strategy/data management/program management. Both are yes if you frame Zero Undeliverables as program management.
